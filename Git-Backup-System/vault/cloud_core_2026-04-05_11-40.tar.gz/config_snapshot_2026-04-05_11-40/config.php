<?php
$CONFIG = array (
  'htaccess.RewriteBase' => '/',
  'memcache.local' => '\\OC\\Memcache\\APCu',
  'apps_paths' => 
  array (
    0 => 
    array (
      'path' => '/var/www/html/apps',
      'url' => '/apps',
      'writable' => false,
    ),
    1 => 
    array (
      'path' => '/var/www/html/custom_apps',
      'url' => '/custom_apps',
      'writable' => true,
    ),
  ),
  'upgrade.disable-web' => true,
  'instanceid' => 'oc599ainoany',
  'passwordsalt' => '7pLe91059dirhRonJKYOC3UB0pu5IA',
  'secret' => 'dM9DLcDdlPtTK9+Np3Y7gjNVCQND+hU+MlvewtCQAnbY0ofT',
  'trusted_domains' => 
  array (
    0 => 'localhost:8081',
  ),
  'datadirectory' => '/var/www/html/data',
  'dbtype' => 'mysql',
  'version' => '33.0.0.16',
  'overwrite.cli.url' => 'http://localhost:8081',
  'dbname' => 'nextcloud',
  'dbhost' => 'db',
  'dbtableprefix' => 'oc_',
  'mysql.utf8mb4' => true,
  'dbuser' => 'nextcloud',
  'dbpassword' => 'favour_user',
  'installed' => true,
);
